import{I as e,n as t}from"./CQnSga0w.js";const o=e(a=>{if(a.path==="/"||a.path==="")return t("/mapa")});export{o as default};
