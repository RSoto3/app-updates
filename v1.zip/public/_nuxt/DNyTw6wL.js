import"./CQnSga0w.js";const r=""+new URL("logo_governa.DoBmSN4T.svg",import.meta.url).href;export{r as _};
